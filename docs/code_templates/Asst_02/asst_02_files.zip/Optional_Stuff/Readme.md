# Readme

* All programs here are non-essential.

* Choose the correct test_Wrapper_variant depending on the .asm/C programme you are using.

* HelloWorld.asm uses only instructions implemented by Assignment 2.

* Others require instructions beyond what is required to be implemented in Assignment 2.

* TOP_Circle_delay_accel_Nexys4*.bit is a prebuilt bitstream corresponding to the Circle_delay_accel program.